@extends('main')

@section('content')
<section class = "hf-sections">

    <h1> Thank you for contacting us. If your inquiry requires a response a representative will contact you.<h1> 
    
    
    <div class="contact-suc-btn">
        <a href="{{ route('hfhome') }}">OK</a>
    </div>
</section>
@endsection