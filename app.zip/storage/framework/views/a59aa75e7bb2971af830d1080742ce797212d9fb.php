

<?php $__env->startSection('content'); ?>
<div>
    <h2>Home PAGE</h2>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HF-Website\resources\views/web/home.blade.php ENDPATH**/ ?>