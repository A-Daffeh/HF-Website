
<header class="header">

  <img src="<?php echo e(asset('img/HF-Logo.jpg')); ?>" alt="HF Logo">
  
  <button class="nav-toggle" aria-label="toggle navigation">
    <span class="nav-toggle-icon"></span>
  </button>
  
  <ul class="nav main-nav">
    <li class="nav-item"><a href="<?php echo e(route('hfhome')); ?>" class="<?php echo e(request()->is('/') ? 'active' : ''); ?>" data-content="Home">Home</a></li>
    <li class="nav-item"><a href="<?php echo e(route('services')); ?>" class="<?php echo e(request()->is('services') ? 'active' : ''); ?>" data-content="Services">Services</a></li>
    <li class="nav-item"><a href="<?php echo e(route('about-us')); ?>" class="<?php echo e(request()->is('about-us') ? 'active' : ''); ?>" data-content="About Us">About Us</a></li>
    <li class="nav-item"><a href="<?php echo e(route('contact')); ?>" class="<?php echo e(request()->is('contact') ? 'active' : ''); ?>" data-content="Contact">Contact</a></li>
    <li class="nav-item"><a href="<?php echo e(route('login')); ?>" class="<?php echo e(request()->is('login') ? 'active' : ''); ?>" data-content="Log in">Log In</a></li>
  </ul>
</header>

<script>
      const navToggle = document.querySelector('.nav-toggle');
      const navMenu = document.querySelector('.nav');
      
      navToggle.addEventListener('click', () => {
        navToggle.classList.toggle('active');
        navMenu.classList.toggle('active');
      });
    </script>

    </body>
<?php /**PATH C:\xampp\htdocs\HF-Website\resources\views/layouts/header.blade.php ENDPATH**/ ?>