

<?php $__env->startSection('content'); ?>
<section class = "hf-sections">

    <h1 class> Thank you for taking the time to contact us! We will get back to you as soon as possible <h1> 
    <div class="cont-suc-img">
        <img src="<?php echo e(asset('img/projectlogo.jpg')); ?>" alt="HF Logo" >
    </div>
    
    <div class="contact-suc-btn">
        <a href="<?php echo e(route('hfhome')); ?>">Back to Home</a>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HF-Website\resources\views/web/contact-success.blade.php ENDPATH**/ ?>