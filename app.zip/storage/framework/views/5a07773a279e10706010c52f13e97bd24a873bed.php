You have contacted by <?php echo e($name); ?> please go www.hfadultfamily.com to see.

Thanks.<?php /**PATH C:\xampp\htdocs\HF-Website\resources\views/confirm-contact.blade.php ENDPATH**/ ?>