<footer id="footer">   
   <div class="hf-footer">
        <div class="hf-flinks">
            <ul>
                <li><a href="<?php echo e(route('hfhome')); ?>" data-content="Home">Home</a></li>
                <li><a href="<?php echo e(route('services')); ?>" data-content="Services">Services</a></li>
                <li><a href="<?php echo e(route('about-us')); ?>" data-content="About Us">About Us</a></li>
                <li><a href="<?php echo e(route('contact')); ?>" data-content="Contact">Contact</a></li>
            </ul>
        </div>

        <div class="hf-fcontact">
            <h3>Contact</h3>
            <ul>
                <li><img src="<?php echo e(asset('img/clock-icon.jfif')); ?>" alt="Clock Icon"> Open 24/7 Monday - Sunday</li>
                <li><img class = "location" src="<?php echo e(asset('img/location-icon.jfif')); ?>" alt="Location Icon"> 18804 43rd Avenue W, Lynnwood WA 98036</li>
                <li><img class = "Phone" src="<?php echo e(asset('img/phone-icon.jfif')); ?>" alt="Phone Icon"> 425-835-0159</li>
            </ul>
        </div>

        <div class="hf-fsocial">
            <h3>Social Media</h3>
            <ul>
                <li><a href=""><img src="<?php echo e(asset('img/facebook-icon.png')); ?>" alt="Facebook Icon"></a></li>
            </ul>
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\HF-Website\resources\views/layouts/footer.blade.php ENDPATH**/ ?>